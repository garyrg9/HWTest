﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Interface
{
    public interface iDisplay
    {
        string message { get; set; }
        string display();
    }
}
