﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Interface
{
    /// <summary>
    /// HelloWorld Interface 
    /// </summary>
    public interface iHelloWorld
    {
        /// <summary>
        /// SetDisplay Method to set the custom display class
        /// </summary>
        /// <param name="in_id"></param>
        void SetDisplay(iDisplay in_id);
        /// <summary>
        /// display method
        /// </summary>
        /// <returns></returns>
        string Display();
    }
}
