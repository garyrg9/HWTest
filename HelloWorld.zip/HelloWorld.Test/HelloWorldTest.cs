﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorld.Core;

namespace HelloWorld.Test
{
    [TestClass]
    public class HelloWorldTest
    {
        [TestMethod]
        public void Test_HelloWorld_Console()
        {
            string s_TypeDisplay = "Console";
            string s_HwClass = "UHelloWorld";
            string s_displayClass = "CDisplay";
            string s_message = "Console Test";
            string s_expected = String.Format("{0}: {1}", s_TypeDisplay, s_message);
            aHelloWorld oHelloWorld = aHelloWorld.Factory(s_HwClass, s_displayClass, s_message);
            string result = oHelloWorld.Display();

            Assert.AreEqual(s_expected, result);

        }
        [TestMethod]
        public void Test_HelloWorld_Special()
        {
            string s_TypeDisplay = "Special";
            string s_HwClass = "UHelloWorld";
            string s_displayClass = "SDisplay";
            string s_message = "Special Test";
            string s_expected = String.Format("{0} Display: {1}", s_TypeDisplay, s_message);
            aHelloWorld oHelloWorld = aHelloWorld.Factory(s_HwClass, s_displayClass, s_message);
            string result = oHelloWorld.Display();

            Assert.AreEqual(s_expected, result);

        }
    }
}


 //<add key = "HelloWorldClass" value="UHelloWorld"/>
 //   <add key = "DisplayClass1" value="CDisplay"/>
 //   <add key = "DisplayClass2" value="SDisplay"/>
 //   <add key = "DisplayMessage1" value="Hello, World!"/>
 //   <add key = "DisplayMessage2" value="World, hello...."/>
