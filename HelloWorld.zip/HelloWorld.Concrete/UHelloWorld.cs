﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Core
{
    /// <summary>
    /// Generic Hello World Class to use displays
    /// </summary>
    public class UHelloWorld : aHelloWorld
    {

    }
}
