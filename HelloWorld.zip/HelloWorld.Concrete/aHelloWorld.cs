﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorld.Interface;
using System.Reflection;

namespace HelloWorld.Core
{
    public abstract class aHelloWorld : iHelloWorld
    {
        protected iDisplay id { get; set; }
        public void SetDisplay(iDisplay in_iDisplay)
        {
            id = in_iDisplay;
        }
        public aHelloWorld()
        {
        }
        public virtual string Display()
        {
            return id.display();
        }
        public static aHelloWorld Factory(string in_class, string in_display_class, string in_message)
        {
            aHelloWorld oaHelloWorld = null;
            if (!string.IsNullOrEmpty(in_class) && !string.IsNullOrEmpty(in_display_class))
            {
                aDisplay oaDisplay = aDisplay.Factory(in_display_class, in_message);

                string s_Class = in_class.StartsWith("HelloWorld.Core") ? in_class : "HelloWorld.Core." + in_class;
                oaHelloWorld = (aHelloWorld)Assembly.GetExecutingAssembly().CreateInstance(s_Class);
                oaHelloWorld.SetDisplay(oaDisplay);
            }

            return oaHelloWorld;
        }
    }
}
