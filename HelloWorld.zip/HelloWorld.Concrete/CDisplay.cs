﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Core
{
    public class CDisplay : aDisplay
    {
        protected override string TypeDisplay { get { return "Console"; } }
    }
}
