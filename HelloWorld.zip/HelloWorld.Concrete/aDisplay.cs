﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorld.Interface;
using System.Reflection;

namespace HelloWorld.Core
{ 
    public abstract class aDisplay : iDisplay
    {
        protected virtual string TypeDisplay {  get { return "Not Implemented";  } } 
        public string message { get; set; }
        public aDisplay()
        {
        }
        /// <summary>
        /// virtual method to dislay
        /// </summary>
        /// <returns></returns>
        public virtual string display()
        {
            string s_display = String.Format("{0}: {1}", this.TypeDisplay, this.message);
            Console.WriteLine(s_display);
            return s_display;
        }
        /// <summary>
        /// Factory to get the appropriate Class
        /// </summary>
        /// <param name="in_class"></param>
        /// <param name="in_message"></param>
        /// <returns></returns>
        public static aDisplay Factory(string in_class, string in_message)
        {
            aDisplay oaDisp = null;
            if (!string.IsNullOrEmpty(in_class))
            {
                string s_Class = in_class.StartsWith("HelloWorld.Core") ? in_class : "HelloWorld.Core." + in_class;
                oaDisp = (aDisplay)Assembly.GetExecutingAssembly().CreateInstance(s_Class);
                oaDisp.message = in_message;
            }

            return oaDisp;
        }

    }
}
