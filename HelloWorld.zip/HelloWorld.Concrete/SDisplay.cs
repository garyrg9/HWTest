﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld.Core
{
    /// <summary>
    /// Special Display class (Whatever that means!)
    /// </summary>
    public class SDisplay : aDisplay
    {
        protected override string TypeDisplay { get { return "Special"; } }
        /// <summary>
        /// This time we override the display method
        /// </summary>
        /// <returns></returns>
        public override string display()
        {
            string s_display = String.Format("{0} Display: {1}", this.TypeDisplay, this.message);
            Console.WriteLine(s_display);
            return s_display;
        }
    }
}
