﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorld.Core;

namespace HelloWorld.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            string s_HwClass = ConfigurationManager.AppSettings["HelloWorldClass"];
            string s_displayClass = ConfigurationManager.AppSettings["DisplayClass1"];
            string s_message = ConfigurationManager.AppSettings["DisplayMessage1"];
            aHelloWorld oHelloWorld = aHelloWorld.Factory(s_HwClass, s_displayClass, s_message);
            oHelloWorld.Display();

            s_HwClass = ConfigurationManager.AppSettings["HelloWorldClass"];
            s_displayClass = ConfigurationManager.AppSettings["DisplayClass2"];
            s_message = ConfigurationManager.AppSettings["DisplayMessage2"];
            oHelloWorld = aHelloWorld.Factory(s_HwClass, s_displayClass, s_message);
            oHelloWorld.Display();
        }
    }
}
